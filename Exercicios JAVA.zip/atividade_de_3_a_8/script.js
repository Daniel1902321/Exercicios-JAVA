let saldo = document.querySelector ("#saldo")
let resultado = document.querySelector("#resultado")

function calcularReajuste(){
    let var1;
    var1=Number(saldo.value);


    resultado.textContent=var1 * 1.01

   



}