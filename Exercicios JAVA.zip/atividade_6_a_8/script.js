function calcularMenor() {
    let var1 = parseFloat(document.querySelector("#PValor").value);
    let var2 = parseFloat(document.querySelector("#SValor").value);
    let var3 = parseFloat(document.querySelector("#TValor").value);
    let var4 = parseFloat(document.querySelector("#QValor").value);

let menor = Math.min(var1, var2, var3, var4);
document.getElementById("resultado").textContent = "O menor numero e: " + menor;

}