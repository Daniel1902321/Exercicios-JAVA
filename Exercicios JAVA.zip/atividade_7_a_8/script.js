function verificarImpar() {

    var numero = document.querySelector("#numero").value;

   
    if (numero % 2 !== 0) {
        document.querySelector("#resultado").innerText = numero + "número ímpar.";
    } else {
        document.querySelector("#resultado").innerText = numero + " número par.";
    }
}